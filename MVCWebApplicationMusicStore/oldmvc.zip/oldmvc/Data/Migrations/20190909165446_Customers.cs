﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MVCWebApplicationMusicStore.Data.Migrations
{
    public partial class Customers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
